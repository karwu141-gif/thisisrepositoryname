# First GAWHS Summer Coding Program

A Pen created on CodePen.

Original URL: [https://codepen.io/Karter-Wu/pen/NPdjjQJ](https://codepen.io/Karter-Wu/pen/NPdjjQJ).

