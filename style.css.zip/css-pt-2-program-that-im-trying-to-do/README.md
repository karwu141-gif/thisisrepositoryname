# CSS (pt.2) Program that Im trying to do

A Pen created on CodePen.

Original URL: [https://codepen.io/Karter-Wu/pen/azpWxJa](https://codepen.io/Karter-Wu/pen/azpWxJa).

